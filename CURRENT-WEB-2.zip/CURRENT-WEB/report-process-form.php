<?php

$email = $_POST["email"];
$num = $_POST["num"];
$dept = $_POST["dept"];
$rep = $_POST["rep"];


$host = "localhost";
$dbname = "report_db";
$username = "root";
$password = "root";

$conn = mysqli_connect($host, $username, $password, $dbname, 3307);

if (mysqli_connect_errno()){
	die("Connection Error: ". mysqli_connect_error());
}

$sql = "INSERT INTO report (email, num, dept, rep)
		VALUES (?, ?, ?, ?)";

$stmt = mysqli_stmt_init($conn);

if ( ! mysqli_stmt_prepare($stmt, $sql)){
	die(mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "siis",
					   $email,
					   $num,
					   $dept,
					   $rep);

mysqli_stmt_execute($stmt);
echo "REPORT SENT. HELP IS ON THE WAY";

?>