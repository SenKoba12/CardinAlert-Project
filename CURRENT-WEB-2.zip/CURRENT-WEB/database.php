<?php


$host = "localhost";
$dbname = "login_db";
$username = "root";
$password = "root";


$mysqli = new mysqli($host, $username, $password, $dbname, 3307);

if ($mysqli->connect_errno){
	die("Connection Error: " . $mysqli->connect_error);
}

return $mysqli;

?>