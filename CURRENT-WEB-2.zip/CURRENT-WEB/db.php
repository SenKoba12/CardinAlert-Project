<?php

$host = "localhost";
$dbname = "report_db";
$username = "root";
$password = "root";

$con = mysqli_connect($host, $username, $password, $dbname, 3307);

if(!$con){
	die("Connection Error");
}

?>