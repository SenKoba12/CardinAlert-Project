<?php

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"]=== "POST"){

  $mysqli = require __DIR__ . "/database.php";

  $sql = sprintf("SELECT * FROM user
          WHERE email = '%s'",
          $mysqli->real_escape_string($_POST["email"]));

  $result = $mysqli->query($sql);

  $user = $result->fetch_assoc();

  if ($user){
    if(password_verify($_POST["password"], $user["password_hash"])){

      session_start();

      session_regenerate_id();

      $_SESSION["user_id"] = $user["id"];

      header("Location: index.php");
      exit;
    }
  }

  $is_invalid = true;
}
?>


<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>CARDINALERT ADMIN</title> 
    <link rel="stylesheet" href="styles.css">
    </head>
  <body>
    <div class="container">
      <div class="wrapper">
        <div class="title"><span>ADMIN LOGIN</span></div>

        <?php if($is_invalid): ?>
          <em>INVALID LOGIN</em>
        <?php endif; ?>


        <form method="POST">
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="email" name="email" placeholder="Enter Email" id="email" value="<?= htmlspecialchars($_POST["email"] ?? "")?>" required>
          </div>
          <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" id="password" required>
          </div>
          <div class="row button">
            <input type="submit" value="Login">
          </div>
        </form>
      </div>
    </div>


	<div class = "preFooter">
		<div class = "column1">
			<p><b>CardinAlert</b><br>
				<br>Helping keep students safe and secure within the campus.</p>
		</div>
		<div class = "column2">
			<p><b>Site Authors:</b>
				<ul>
					<li>Esteron</li>
          <li>Laurenio</li>
          <li>Ong</li>
          <li>Tanate</li>
          <li>Vertudes</li>
				</ul>
				</p>
		</div>

		<div class = "column3">
			<img src="logover2.png" height = "100px" width = "100px">
		</div>

	</div>
	
	
	<footer><div id="copyright">&copy;2023- <strong>IT120P Group 2: CardinAlert</strong></div></footer>
	

  </body>
</html>