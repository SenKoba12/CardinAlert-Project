<?php

session_start();

if (isset($_SESSION["user_id"])){

	$mysqli = require __DIR__ . "/database.php";

	$sql = "SELECT * FROM user
			WHERE id = {$_SESSION["user_id"]}";

	$result = $mysqli->query($sql);

	$user = $result->fetch_assoc();
}

require_once('db.php');
$query = "SELECT * FROM report";
$res = mysqli_query($con, $query);

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>DATABASE LIST</title>
	<link rel="stylesheet" href="bootstrap.min.css">

</head>
<body class="bg-dark">
		<div class="container">
			<div class="row mt-5">
				<div class="col">
					<div class="card mt-5">
						<div class="card-header">
							<h2 class="display-6 text-center">STUDENT REPORT LIST</h2>
						</div>

						<div class="card-body">
							<table class="table table-bordered text-center">
								<tr class="bg-dark text-white">
									<td> EMAIL </td>
									<td> STUDENT NUMBER </td>
									<td> DEPARTMENT </td>
									<td> REPORT </td>
								</tr>

								<tr>
									<?php
										while($row = mysqli_fetch_assoc($res)){
											?>
											<td><?php echo $row['email'];?></td>
											<td><?php echo $row['num'];?></td>
											<td><?php echo $row['dept'];?></td>
											<td><?php echo $row['rep'];?></td>
								</tr>
									<?php
										}
									?>


							</table>
						</div>

					</div>
				</div>
			</div>
		</div>

		<?php if(isset($user)): ?>

			<p>Hello <?= htmlspecialchars($user["name"]) ?></p>

			<p><a href="index-1.php">Log Out</a> or <a href="create-user.html">sign up</a></p>

		<?php else: ?>
			<p><a href="index.php">Log in</a> or <a href="create-user.html">sign up</a></p>

		<?php endif; ?>
</body>
</html>