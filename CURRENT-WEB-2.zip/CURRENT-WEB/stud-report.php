<!DOCTYPE html>
<html>
    <head><title>INCIDENT REPORT</title>
    <link rel="stylesheet" href="report-style.css">
    </head>

<body>

<div class="formbold-main-wrapper">
    <div class="formbold-form-wrapper">
        <div>
            <h1 class="formbold-form-label" style="font-size: 30px; text-align: center;">INCIDENT REPORT</h1>
          </div>
      <form action="report-process-form.php" method="POST">
        <div class="formbold-input-group">
            <label for="name" class="formbold-form-label"> ENTER EMAIL </label>
            <input
              type="text"
              name="email"
              id="email"
              placeholder="Enter Email"
              class="formbold-form-input"
            />
          </div>

        <div class="formbold-input-group">
          <label for="name" class="formbold-form-label"> STUDENT NUMBER </label>
          <input
            type="number"
            name="num"
            id="num"
            placeholder="Enter Student Number"
            class="formbold-form-input"
          />
        </div>
  
        <div class="formbold-input-radio-wrapper">
          <label for="ans" class="formbold-form-label">
            Select a department for the report to be forwarded:
          </label>
  
          <div class="formbold-radio-flex">
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="dept"
                  id="dept1"
                  value="1"
                />
                Department 1
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
  
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="dept"
                  id="dept2"
                  value="2"
                />
                Department 2
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
  
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="dept"
                  id="dept3"
                  value="3"
                />
                Department 3
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
          </div>
        </div>
  
       
        <div>
          <label for="message" class="formbold-form-label">
            Write Report Here:
          </label>
          <textarea
            rows="6"
            name="rep"
            id="report"
            placeholder="Enter Report:"
            class="formbold-form-input"
          ></textarea>
        </div>
  
        <button type="submit" class="formbold-btn" name="submit" id="submit">Submit</button>

        <div class="formbold-input-group">
          <input type="text" id="numbers">
        </div>

        <div class="form-group">
          <input type="text" id="access_token" placeholder="Access Token" value = "o.7TrNOSzbcFhxNnIygySAoweOLNqUbSt1">
        </div>

        <div>
          <input type="text" id="devices" placeholder="Devices Name" value="Samsung SM-A326B">
        </div>
      </form>
    </div>
  </div>

<?php

require_once '../htdocs/vendor/autoload.php';

if(isset($_POST['numbers']) && isset($_POST['report'])){

  $numbers = $_POST['numbers'];
  $message = $_POST['report'];

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  $pb = new Pushbullet\Pushbullet($_POST['access_token']);

  foreach(explode("," , $numbers) as $phone){

    $res = $pb->device($_POST['Samsung SM-A326B'])->sendSms('+63'.$phone, $message);

    if ($res){
      $data = array(
        "response" => "success",
        "current" => '+63'.$phone
      );
      echo json_encode($data);
    }
  }

}

?>

 </body>
  </html>